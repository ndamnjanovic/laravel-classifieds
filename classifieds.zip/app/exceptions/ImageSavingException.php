<?php

use Exception;

class ImageSavingException extends Exception {

}