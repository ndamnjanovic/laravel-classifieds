<?php

return array(
  'mail' => 'enter_your_email_here'
);

?>