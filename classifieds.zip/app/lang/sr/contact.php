<?php

return array(
  'your_name' => 'Vaše ime i prezime',
  'your_email' => 'Vaše email',
  'your_comment' => 'Vaš komentar',
  'send_btn' => 'Pošalji',
);