<?php

return array(
  'home' => 'Početna',
  'today' => 'Danas',
  'contact' => 'Kontakt',
  'all_rights_reserved' => 'Sva prava zadržana',
  'categories_label' => 'Kategorije',
  'submit_classified' => 'Postavi oglas',
  'contact_email' => array(
    'title' => 'Kontakt - mali oglasi',
    'send-success' => 'Vaša poruka je uspešno poslata. Javićemo Vam se u najkraćem roku.'
  )
);