<?php

  return array(
    'email' => array(
      'send' => 'Error occurred while trying to send your email. Please try again.'
     ),
  );