<?php

  return array(
    'email' => array(
      'send' => 'Dogodila se greška prilikom slanja poruke. Molimo Vas da probate ponovo. Hvala na razumevanju.'
     ),
  );