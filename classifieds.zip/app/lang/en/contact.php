<?php

return array(
  'your_name' => 'Your name',
  'your_email' => 'Your email',
  'your_comment' => 'Your comment',
  'send_btn' => 'Send',
);