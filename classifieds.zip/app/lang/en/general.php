<?php

return array(
  'home' => 'Home',
  'today' => 'Today',
  'contact' => 'Contact',
  'all_rights_reserved' => 'All rights reserved',
  'categories_label' => 'Categories',
  'submit_classified' => 'Submit classified',
  'contact_email' => array(
    'title' => 'Contact - classifieds',
    'send-success' => "Your message is sent. We'll get in touch with you"
  )
);