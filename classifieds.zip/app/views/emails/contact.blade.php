<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>{{Lang::get('general.contact_email.title')}}</title>
    <style type="text/css">
    <!--

      body {
        font-family:Verdana, Arial, Helvetica, sans-serif;
        font-size:9pt;
        line-height:150%;
        padding:0;
        margin:10px 0;
        text-align:left;
        color:#333333;
      }

      a {
        color: #215C7A;
        text-decoration: none;
        border: 0;
        font-weight: bold;
      }

      a:hover {
        text-decoration: underline;
        border: 0;
      }

      .title {
        color:#215C7A;
        background:#f2f2f2;
        font-weight:bold;
        text-align:center;
      }

      hr {
        border: 0;
        color: #215C7A;
        background-color: #215C7A;
        height: 1px;
        width: 100%;
        text-align: left;
      }

      .lightblue {
        color:#215C7A;
      }

      .small {
        font-size:7pt;
        color:#777777;
      }

      .style1 {
        color: #215C7A
      }
    -->
    </style>
  </head>
  <body bgcolor="#E3E3E3">
    <table align="center" width="600" cellspacing="0" cellpadding="0" border="0" bgcolor="#ffffff">
      <tr>
        <td><table cellpadding="8" cellspacing="0" width="100%">
            <tr>
              <td align="center">
              </td>
            </tr>
            <tr>
              <td>
              {{$comment}}
              </td>
            </tr>
            <tr>
              <td>
                <hr />
                <span class="small">
                  &copy; All Rights Reserved <?php echo date('Y') ?>
                </span>
              </td>
            </tr>
          </table></td>
      </tr>
    </table>
  </body>
</html>

