 <meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="">

<title>Šabačka čivija - mali oglasi grada Šapca</title>

<!-- Bootstrap core CSS -->
<link id="switch_style" href="{{URL::asset('css/bootstrap.css')}}" rel="stylesheet">

<!-- Custom styles for this template -->
<link href="{{URL::asset('css/theme.css')}}" rel="stylesheet">
<link href="{{URL::asset('css/custom.css')}}" rel="stylesheet">
<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
<link rel="stylesheet" href="{{URL::asset('fancybox/jquery.fancybox.css')}}" type="text/css" media="screen" />

<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
<script src="../../assets/js/html5shiv.js"></script>
<script src="../../assets/js/respond.min.js"></script>
<![endif]-->