<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script type="text/javascript" src="{{URL::asset('js/jquery-2.1.1.min.js')}}"></script>
<script type="text/javascript" src="{{URL::asset('fancybox/jquery.fancybox.pack.js')}}"></script>
<script type="text/javascript" src="{{URL::asset('js/classifieds.js')}}"></script>