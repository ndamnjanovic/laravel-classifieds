$(document).ready(function() {
  $('.fancybox').fancybox();
});
